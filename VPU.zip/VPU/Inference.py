import cv2
import numpy as np
from openvino.inference_engine import IECore

# Load IR files into OpenVINO
ie = IECore()
net = ie.read_network(model='path/to/model.xml', weights='path/to/model.bin')
input_blob = next(iter(net.input_info))
output_blob = next(iter(net.outputs))

# Load image
image = cv2.imread('path/to/image.jpg')
image = cv2.resize(image, (input_blob.input_data.shape[3], input_blob.input_data.shape[2]))
image = image.transpose((2, 0, 1))
image = image.reshape(1, *image.shape)

# Prepare input data
input_data = {input_blob: image}

# Run inference
exec_net = ie.load_network(network=net, device_name='CPU')
result = exec_net.infer(inputs=input_data)[output_blob]

# Postprocess result
result = np.squeeze(result)

# Print the result
print(result)
